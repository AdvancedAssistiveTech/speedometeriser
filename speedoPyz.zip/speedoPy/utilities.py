def contains(superstring, substring):
    for a in range(len(superstring) + 1):
        if superstring[a:len(substring) + a] == substring:
            return True
    return False


def format_time(hhmmss):
    h = 0
    m = 0
    s = 0
    if len(hhmmss) > 6:
        hhmmss = hhmmss[:6]
    if len(hhmmss) == 6:
        h = int(hhmmss[:2])
        m = int(hhmmss[2:4])
        s = int(hhmmss[4:6])
    elif len(hhmmss) == 4:
        m = int(hhmmss[:2])
        s = int(hhmmss[2:4])
    elif len(hhmmss) == 2:
        s = int(hhmmss)
    else:
        print("ERROR: irregular input. please format inputs with even omissions")
        return False
    return h, m, s
