from time import time
from datetime import datetime
import utilities as utl


def sandbox_func():
    print("howdy")  # write experimental functions here


start_timeb = False
while True:
    assistant = False  # 025331 //example input
    stopwatch = False
    uinput = True
    ui = ""
    start_time = ""
    while not start_timeb:
        start_time = input("enter start time (hhmmss): ")
        if start_time == "skp":  # if inputting of time is bypassed
            print("WARNING: START TIME NOT SPECIFIED\n")
            break
        else:
            h, m, s = utl.format_time(start_time)
            start_time = ((h * 3600) + (m * 60) + s)  # formats start time as seconds
            start_timeb = True
    while uinput:
        if utl.contains(ui, "ext"):
            uinput = False
            stopwatch = False
            break
        ui = input("input:\n")
        if ui == "":  # default function, engages when enter is pressed
            assistant = True  # initiates assistant function
            stopwatch = False
            uinput = False
        elif utl.contains(ui, "init"):
            if ui == "init":  # if user only inputted "init", without a followup command
                ui += input("init: ")
            print("Processing syntax...\n")
            if utl.contains(ui, "speed") or utl.contains(ui, "stopwatch"):
                stopwatch = True
                uinput = False
                assistant = False
            elif utl.contains(ui, "assist"):
                assistant = True
                stopwatch = False
                uinput = False
        elif utl.contains(ui, "exit"):
            uinput = False
            stopwatch = False
            break
        else:
            print("invalid input, try again")
    while stopwatch:
        ui = input("'enter' to start stopwatch, any other input to terminate stopwatch ")
        if ui == "":
            msecondsa = time() * 1000  # grabs system time at initialisation of stopwatch in ms
            input("'enter' to stop stopwatch")
            msecondsb = time() * 1000  # grabs system time at termination of stopwatch in ms
            distance = input("Distance travelled (km): ")
            time = ((msecondsb - msecondsa) / 10) / 100  # compares initialisation and termination times to determine cs passed
            speed = float(distance) * (3600 / time)  # ancient and immutable equation determined years ago by legendary mathematician, Aidan Naude
            print(round(speed), "km/h")
        else:
            stopwatch = False
            uinput = True
    while assistant:
        eta = 0
        etd = 0
        spd = 0
        uin = True
        while uin:
            uin = False
            eta = input("eta (hhmmss): ")
            if not utl.format_time(eta):
                uin = True
            else:
                h, m, s = utl.format_time(eta)
                eta = (h + float(m / 60) + float(s / 3600))  # formats etd as hours
        uin = True
        while uin:
            uin = False
            spd = input("section speed: ")
            if len(spd) > 3:
                spd = spd[:3]
            if input("confirm speed as " + spd + "km/h") != "":
                uin = True
        spd = float(spd)
        dist = round(spd * eta, 2)
        sc = input("calculated distance = " + str(dist))
        if sc != "":
            dist = sc
        sc = "z"
        while sc != "ext":
            sc = input("input: ")
            if utl.contains(sc, ""):
                cdist = float(input("current distance: "))
                rs = (cdist / spd) * 3600  # real time
                rm = 0
                rh = 0
                while rs >= 60:
                    rs -= 60
                    rm += 1
                    if rm >= 60:
                        rm -= 60
                        rh += 1
                if not start_timeb:
                    h, m, s = utl.format_time(input("start time unknown. enter current time (hhmmss): "))  # current time
                    fs = ((h * 3600) + (m * 60) + s)
                else:
                    h, m, s = utl.format_time(datetime.now().strftime("%H%M%S"))
                    fs = ((h * 3600) + (m * 60) + s) - float(start_time)  # false time
                fm = 0
                fh = 0
                while fs >= 60:
                    fs -= 60
                    fm += 1
                    if fm >= 60:
                        fm -= 60
                        fh += 1
                nh = fh - rh
                nm = fm - rm
                ns = fs - rs
                while ns >= 60:
                    ns -= 60
                    nm += 1
                    if nm >= 60:
                        nm -= 60
                        nh += 1
                print("current time:", fh, ":", fm, ":", fs, "required time:", rh, ":", rm, ":", rs, "net time:", nh, ":", nm, ":", ns)
                if nh > 0:
                    print(nh, "hour/s late")
                elif nh < 0:
                    print(nh / -1, "hour/s early")
                if nm > 0:
                    print(nm, "minute/s late")
                elif nm < 0:
                    print(nm / -1, "minute/s early")
                if ns > 0:
                    print(ns, "second/s late")
                elif ns < 0:
                    print(ns / -1, "second/s early")
    break
