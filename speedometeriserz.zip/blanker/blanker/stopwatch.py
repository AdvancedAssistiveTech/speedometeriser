from time import time


def contains(superstring, substring):
    for a in range(len(superstring) + 1):
        if superstring[a:len(substring) + a] == substring:
            return True
    return False


def format_time(hhmmss):
    h = 0
    m = 0
    s = 0
    if len(hhmmss) > 6:
        hhmmss = hhmmss[:6]
    if len(hhmmss) == 6:
        h = int(hhmmss[:2])
        m = int(hhmmss[2:4])
        s = int(hhmmss[4:6])
    elif len(hhmmss) == 4:
        m = int(hhmmss[:2])
        s = int(hhmmss[2:4])
    elif len(hhmmss) == 2:
        s = int(hhmmss)
    else:
        print("ERROR: irregular input. please format inputs with even omissions")
        return False
    return h, m, s


def sandbox():  # 025331 //example input
    eta = 0
    etd = 0
    spd = 0
    # etd = (h + float(m / 60) + float(s / 3600))  # formats etd as hours
    uin = True
    while uin:
        uin = False
        etd = input("etd (hhmmss): ")
        if not format_time(etd):
            uin = True
        else:
            h, m, s = format_time(etd)
            etd = (h + float(m / 60) + float(s / 3600))  # formats etd as hours
    print(etd)
    uin = True
    while uin:
        uin = False
        eta = input("eta (hhmmss): ")
        if not format_time(eta):
            uin = True
        else:
            h, m, s = format_time(eta)
            eta = (h + float(m / 60) + float(s / 3600))  # formats etd as hours
    print(eta)
    uin = True
    while uin:
        uin = False
        spd = input("section speed: ")
        if len(spd) > 3:
            spd = spd[:3]
        if input("confirm speed as " + spd + "km/h") != "":
            uin = True
    spd = float(spd)
    dist = round(spd * eta, 2)
    sc = input("calculated distance = " + str(dist))
    if sc != "":
        dist = sc
    sc = "z"
    while sc != "":
        sc = input("input: ")
        if contains(sc, "chk"):
            cdist = float(input("current distance: "))
            rs = (cdist / spd) * 3600  # real time
            rm = 0
            rh = 0
            while rs >= 60:
                rs -= 60
                rm += 1
                if rm >= 60:
                    rm -= 60
                    rh += 1
            fh, fm, fs = format_time(input("current time (hhmmss): "))  # fake time
            nh = fh - rh
            nm = fm - rm
            ns = fs - rs
            print("current time:", fh, ":", fm, ":", fs, "required time:", rh, ":", rm, ":", rs, "net time:", nh, ":", nm, ":", ns)
            
    
while True:
    sandbox()

stopwatch = False
uinput = True
ui = ""
while True:
    while uinput:
        if contains(ui, "exit"):
            uinput = False
            stopwatch = False
            break
        ui = input("input:\n")
        if ui == "":
            stopwatch = True
            uinput = False
        elif contains(ui, "init"):
            if ui == "init":
                ui += input("init: ")
            print("Processing syntax...\n")
            if contains(ui, "speed") or contains(ui, "stopwatch"):
                stopwatch = True
                uinput = False
        elif contains(ui, "exit"):
            uinput = False
            stopwatch = False
            break
        else:
            print("invalid input, try again")
    while stopwatch:
        ui = input("'enter' to start stopwatch, any other input to terminate stopwatch ")
        if ui == "":
            msecondsa = time() * 1000  # grabs system time at initialisation of stopwatch in ms
            input("'enter' to stop stopwatch")
            msecondsb = time() * 1000  # grabs system time at termination of stopwatch in ms
            distance = input("Distance travelled (km): ")
            time = ((msecondsb - msecondsa) / 10) / 100  # compares initialisation and termination times to determine cs passed
            speed = float(distance) * (3600 / time)  # ancient and immutable equation determined years ago by legendary mathematician, Aidan Naude
            print(round(speed), "km/h")
        else:
            stopwatch = False
            uinput = True
    break
