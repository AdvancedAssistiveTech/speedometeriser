key = input("Key: ")
value = input("Value: ")
p = {key:value}
print(p)
for i in range(10):
    key = input("Key: ")
    value = input("Value: ")
    p[key] = value
    print(p)
