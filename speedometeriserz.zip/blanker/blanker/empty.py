def add(a, b):
    return a + b


def print_fibonacci(looptimes):
    b = 0
    c = 1
    for i in range(0, looptimes):
        d = b + c
        print(d)
        b = d + c
        print(b)
        c = b + d
        print(c)


def is_prime(candidate):
    for a in range(2, candidate - 1):
        if candidate % a == 0:
            return False
    return True
    pass


def print_primes_until(target=10):
    for i in range(0, target + 1):
        if is_prime(i):
            print(i, "is prime")
        else:
            print(i, "is not prime")


def starts_with(superstring, substring):  # case sensitive
    if superstring[0:len(substring)] == substring:
        return True
    else:
        return False


def sum(var1, var2, var3):
    return var1 + var2 + var3


def contains(superstring, substring):
    for a in range(len(superstring)):
        if superstring[a:len(substring) + a] == substring:
            return True
    return False


def ends_with(superstring, substring):
    if superstring[-len(substring):] == substring:
        return True
    return False


print_fibonacci(10)
print("\n")
print_primes_until()
print("\n")
print("is_prime:", is_prime(45))
print("\n")
print("starts_with:", starts_with("Happiness", "H"))
print("\n")
print("contains:", contains("Bucky", "Bucky"))
print("\n")
print("ends_with:", ends_with("Pussy", "sy"))
