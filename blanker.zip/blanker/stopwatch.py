from time import time
input("'enter' to start stopwatch")
msecondsa = time()*1000  # grabs system time at initialisation of stopwatch in ms
input("'enter' to stop stopwatch")
msecondsb = time()*1000  # grabs system time at termination of stopwatch in ms
distance = input("Distance travelled (km): ")
time = ((msecondsb - msecondsa) / 10) / 100  # compares initialisation and termination times to determine cs passed
speed = float(distance) * (3600 / time)  # ancient and immutable equation determined years ago by legendary mathematician, Aidan Naude
print(round(speed), "km/h")
